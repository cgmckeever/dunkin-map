Google Maps / Yahoo Local API Example
Chris McKeever - 2006
Center for Realtor Technology
http://blog.realtors.org/crt/


core.php is the webpage
request.php is the ajax request page which returns data to core.php